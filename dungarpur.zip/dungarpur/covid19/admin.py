from django.contrib import admin
from covid19.models import *

# Register your models here.
admin.site.register(covidinfo)
admin.site.register(bascoinfo)
admin.site.register(udaicoinfo)
admin.site.register(dcoinfo)